# manzanillo-qc

Quantum sensor placement optimisation for the Manzanillo seismic network.

Given a set of candidate deployment locations with seismicity risk weights and
CAPEX estimates, the package solves:

> **Maximise** Σ wᵢ xᵢ &nbsp;&nbsp; subject to &nbsp;&nbsp; Σ cᵢ xᵢ ≤ B, &nbsp; xᵢ ∈ {0,1}

using a QAOA circuit (PennyLane) and benchmarks it against an exact CP-SAT
solver (OR-Tools).

---

## Package layout

```
manzanillo-qc/
├── pyproject.toml
├── requirements.txt
├── requirements-photonic-legacy.txt
├── examples/
│   └── config_small.yaml          8 Manzanillo candidate sites
└── src/manzanillo_qc/
    ├── config.py      Pydantic data models + YAML loader
    ├── instance.py    Live data pipeline (USGS + FDSN → AppConfig)
    ├── qubo.py        QUBO matrix builder + brute-force solver
    ├── ising.py       QUBO → Ising conversion + PennyLane Hamiltonians
    ├── qaoa.py        QAOA circuit + AdamOptimizer loop
    ├── backends.py    PennyLane device factory
    └── cli.py         Command-line entry-point
```

---

## Problem context

The study region covers **18–20°N, 100–105°W** (Manzanillo / Colima, Mexico),
one of the most seismically active segments of the Middle America Trench.
A 20-year USGS catalog (2005–2025, M ≥ 2.0) is used to compute an
energy-weighted risk score per 0.5° grid cell:

```
risk_score_i = Σ_{events in cell i}  10^(1.5 · M)
```

Normalised to [0, 1], this becomes the risk weight wᵢ for each candidate
sensor location.  CAPEX is assigned by sensor tier:

| Sensor type      | CAPEX     | Threshold        |
|------------------|-----------|------------------|
| Broadband        | $100 K    | risk ≥ 0.60      |
| Short-period     | $70 K     | 0.30 ≤ risk < 0.60 |
| MEMS node        | $40 K     | risk < 0.30      |

---

## Modules

### `config.py` — data models

```python
from manzanillo_qc.config import AppConfig, SiteCandidate

cfg = AppConfig.from_yaml("examples/config_small.yaml")
print(cfg.n_sites, cfg.effective_lambda)
```

**`SiteCandidate`** fields: `name`, `lat`, `lon`, `risk_weight` ∈ [0,1],
`capex_10k` (integer, $10 K units), `sensor_type`, `greenfield`.

**`AppConfig`** fields:

| Field | Default | Description |
|-------|---------|-------------|
| `budget_10k` | 25 | Total budget in $10 K units ($250 K) |
| `penalty_lambda` | None | QUBO penalty λ; None → auto = 1 + Σwᵢ |
| `p_layers` | 2 | QAOA circuit depth |
| `n_steps` | 200 | Adam optimiser iterations |
| `stepsize` | 0.01 | Adam learning rate |
| `backend` | `"default.qubit"` | PennyLane device name |
| `sites` | [] | List of SiteCandidate |

---

### `instance.py` — live data pipeline

```python
from manzanillo_qc.instance import fetch_instance

cfg = fetch_instance()          # hits USGS + IRIS FDSN (~5 s)
cfg = fetch_instance(budget_10k=30, p_layers=3)
```

Internally:
1. Pages the USGS FDSN catalog (M ≥ 2.0, 2005–2025) for the study region
2. Queries IRIS FDSN for existing station inventory (XF, ZA, MX networks)
3. Bins events into a 4-lat × 5-lon grid; computes energy-weighted risk scores
4. Selects top-5 risk cells + 3 low-risk-but-active cells as candidates
5. Assigns CAPEX tiers and greenfield flags
6. Returns a fully-populated `AppConfig`

---

### `qubo.py` — QUBO matrix

```python
from manzanillo_qc.qubo import build_qubo, brute_force

Q, meta = build_qubo(cfg)
bf      = brute_force(cfg, Q)
print(bf["obj"], bf["cost"], bf["x"])
```

**Formulation** (minimisation form, n sensor bits only — no slack bits):

```
min f(x) = −Σᵢ wᵢ xᵢ  +  λ · (Σᵢ cᵢ xᵢ − B)²

Q[i,i] = −wᵢ + λ · cᵢ · (cᵢ − 2B)
Q[i,j] =       2λ · cᵢ · cⱼ          (i < j)
```

The penalty λ = 1 + Σwᵢ ensures any budget violation costs more than the
maximum achievable objective gain.

`meta` keys: `n_qubits`, `lambda`, `budget`, `q_min`, `q_max`.

---

### `ising.py` — Ising conversion

```python
from manzanillo_qc.ising import qubo_to_ising, build_pennylane_hamiltonian

h, J         = qubo_to_ising(Q)
H_cost, H_mix = build_pennylane_hamiltonian(h, J)
```

Substitution xᵢ = (1 − σᵢ)/2:

```
hᵢ  = −Q[i,i]/2  −  (1/4) · Σⱼ≠ᵢ Q[min(i,j), max(i,j)]
Jᵢⱼ = Q[i,j] / 4
```

`build_pennylane_hamiltonian` is version-safe: tries
`qml.ops.LinearCombination` (PennyLane ≥ 0.36) then falls back to
`qml.Hamiltonian`.

---

### `qaoa.py` — QAOA circuit

```python
from manzanillo_qc.qaoa import run_qaoa

result = run_qaoa(cfg, h, J)
print(result["best_obj"], result["best_cost"])
print(result["best_x"])          # 0/1 sensor selection vector
```

**Circuit** (p layers, n qubits):

```
|+⟩^⊗n  →  [cost_layer(γₗ) · mixer_layer(βₗ)]_{l=1..p}  →  measure probs
```

**Optimiser**: `qml.AdamOptimizer`, minimises ⟨H_cost⟩ over 2p parameters.
Starts from random [0, π/2] with seed 42.

**Solution extraction**: scans top-500 highest-probability bitstrings from
`qml.probs`, returns the best feasible one (Σcᵢxᵢ ≤ B).

Return dict keys:

| Key | Type | Description |
|-----|------|-------------|
| `best_x` | ndarray | 0/1 sensor selection |
| `best_obj` | float | Risk coverage Σwᵢxᵢ |
| `best_cost` | float | CAPEX Σcᵢxᵢ (in $10K units) |
| `best_prob` | float | Circuit probability of best_x |
| `probs` | ndarray | Full 2ⁿ probability distribution |
| `cost_history` | list | ⟨H_cost⟩ at each Adam step |
| `opt_params` | ndarray | Final [γ₁…γₚ, β₁…βₚ] |
| `final_expval` | float | ⟨H_cost⟩ at last step |

---

### `backends.py` — device factory

```python
from manzanillo_qc.backends import get_device

dev = get_device("default.qubit", n_qubits=8)   # CPU simulator
dev = get_device("lightning.qubit", n_qubits=8) # fast C++ (pip install pennylane-lightning)
dev = get_device("qiskit.aer", n_qubits=8)      # Aer (pip install pennylane-qiskit)
```

---

### `cli.py` — command line

```bash
# From YAML config (no network calls):
manzanillo-qc --config examples/config_small.yaml

# Fetch live data, custom budget:
manzanillo-qc --budget 30

# Save results to JSON:
manzanillo-qc --config examples/config_small.yaml --output results.json
```

Or without installing:

```bash
python -m manzanillo_qc.cli --config examples/config_small.yaml
```

---

## Installation

```bash
# From the manzanillo-qc/ directory:
pip install -e .

# Or just add to sys.path (used in quantum_exp.ipynb):
import sys; sys.path.insert(0, "manzanillo-qc/src")
```

---

## Example: full pipeline in Python

```python
from manzanillo_qc.config import AppConfig
from manzanillo_qc.qubo import build_qubo, brute_force
from manzanillo_qc.ising import qubo_to_ising
from manzanillo_qc.qaoa import run_qaoa

# Load from YAML (or use fetch_instance() for live data)
cfg = AppConfig.from_yaml("examples/config_small.yaml")

# Build QUBO
Q, meta = build_qubo(cfg)
bf      = brute_force(cfg, Q)
print(f"Optimal (brute force): {bf['obj']:.4f}, ${bf['cost']*10:.0f}K")

# Ising + QAOA
h, J   = qubo_to_ising(Q)
result = run_qaoa(cfg, h, J)
gap    = bf["obj"] - result["best_obj"]
print(f"QAOA: {result['best_obj']:.4f}, gap = {gap:.4f} ({100*gap/bf['obj']:.1f}%)")
```

---

## Results from `examples/config_small.yaml`

8 candidate sites, budget = $250 K, p = 2, Adam 200 steps:

| Method | Sensors selected | CAPEX | Coverage Σwᵢxᵢ |
|--------|-----------------|-------|----------------|
| Brute-force (exact) | 0, 1, 2, 3 | $220 K | 1.0201 |
| CP-SAT (OR-Tools) | 0, 1, 2, 3 | $220 K | 1.0201 |
| QAOA (this package) | 0, 1 | $140 K | ~1.0086 |

The QAOA gap of ~1.1% reflects the soft-penalty formulation (no slack bits)
and p = 2 depth.  Increasing `p_layers` or `n_steps` in the config will
narrow the gap at the cost of longer runtime.

---

## Relationship to `quantum_exp.ipynb`

`quantum_exp.ipynb` is the analysis notebook.  Sections §1–§3 fetch data and
build the candidate list inline.  Sections §4–§5 import directly from this
package:

```
quantum_exp.ipynb §4  →  manzanillo_qc.qubo.build_qubo()
quantum_exp.ipynb §5  →  manzanillo_qc.ising + manzanillo_qc.qaoa.run_qaoa()
```

The inline version used 13 variables (8 sensor + 5 slack bits, COBYLA
optimiser).  This package uses 8 variables (soft penalty, Adam optimiser),
matching the PDF specification.

---

## Dependencies

| Package | Version | Role |
|---------|---------|------|
| pennylane | ≥ 0.36 | QAOA circuit + optimiser |
| numpy | ≥ 1.24 | Matrix arithmetic |
| pandas | ≥ 2.0 | Data pipeline |
| pydantic | ≥ 2.0 | Config validation |
| pyyaml | ≥ 6.0 | YAML config loader |
| requests | ≥ 2.28 | USGS / FDSN API calls |
| ortools | ≥ 9.5 | CP-SAT benchmark (CLI) |
| scipy | ≥ 1.10 | Optional (notebook only) |
| matplotlib | ≥ 3.7 | Optional (notebook only) |
