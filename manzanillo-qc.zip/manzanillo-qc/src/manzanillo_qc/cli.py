"""Command-line entry-point for manzanillo-qc.

Usage
-----
    manzanillo-qc --config examples/config_small.yaml
    manzanillo-qc --budget 30 --output results.json
    python -m manzanillo_qc.cli --help
"""
from __future__ import annotations

import argparse
import json
import numpy as np

from .config import AppConfig
from .qubo import build_qubo, brute_force
from .ising import qubo_to_ising
from .qaoa import run_qaoa


def _run(args: argparse.Namespace) -> None:
    # ── Load config ────────────────────────────────────────────────────────────
    if args.config:
        cfg = AppConfig.from_yaml(args.config)
    else:
        from .instance import fetch_instance
        cfg = fetch_instance(budget_10k=args.budget)

    print(f"\nLoaded {cfg.n_sites} site candidates  |  budget = ${cfg.budget_10k * 10}K")
    print(f"Backend: {cfg.backend}  |  p = {cfg.p_layers}  |  steps = {cfg.n_steps}\n")

    # ── QUBO ───────────────────────────────────────────────────────────────────
    Q, meta = build_qubo(cfg)
    print(f"QUBO built: {meta['n_qubits']} qubits  |  \u03bb={meta['lambda']:.3f}"
          f"  |  Q \u2208 [{meta['q_min']:.2f}, {meta['q_max']:.2f}]")

    bf = brute_force(cfg, Q)
    print(f"Brute-force optimal: obj={bf['obj']:.4f}  cost=${bf['cost']*10:.0f}K"
          f"  sensors={list(np.where(bf['x'])[0])}\n")

    # ── Ising + QAOA ──────────────────────────────────────────────────────────
    h, J   = qubo_to_ising(Q)
    result = run_qaoa(cfg, h, J)

    gap = bf["obj"] - result["best_obj"]
    pct = 100 * gap / max(bf["obj"], 1e-9)

    print(f"\n=== QAOA result ===")
    print(f"Coverage : {result['best_obj']:.4f}  (gap {gap:.4f} = {pct:.1f}%)")
    print(f"CAPEX    : ${result['best_cost']*10:.0f}K / ${cfg.budget_10k*10}K")
    print(f"Sensors  : {list(np.where(result['best_x'])[0])}")
    print(f"Prob     : {result['best_prob']:.5f}")

    # ── Optional JSON output ───────────────────────────────────────────────────
    if args.output:
        bf_sensors = list(np.where(bf["x"])[0].tolist()) if bf["x"] is not None else []
        qa_sensors = list(np.where(result["best_x"])[0].tolist())
        out = {
            "brute_force": {"obj": bf["obj"], "cost": bf["cost"], "sensors": bf_sensors},
            "qaoa": {
                "obj":     result["best_obj"],
                "cost":    result["best_cost"],
                "sensors": qa_sensors,
                "prob":    result["best_prob"],
            },
            "gap":     gap,
            "gap_pct": pct,
        }
        with open(args.output, "w") as f:
            json.dump(out, f, indent=2)
        print(f"\nResults saved to {args.output}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="manzanillo-qc",
        description="Quantum sensor placement for the Manzanillo seismic network",
    )
    parser.add_argument(
        "--config", "-c", metavar="YAML",
        help="Path to YAML config file (default: fetch live USGS/FDSN data)",
    )
    parser.add_argument(
        "--budget", "-b", type=int, default=25, metavar="UNITS",
        help="Budget in $10 K units (default: 25 = $250 K). Ignored if --config is set.",
    )
    parser.add_argument(
        "--output", "-o", metavar="JSON",
        help="Write results to a JSON file",
    )
    args = parser.parse_args()
    _run(args)


if __name__ == "__main__":
    main()
