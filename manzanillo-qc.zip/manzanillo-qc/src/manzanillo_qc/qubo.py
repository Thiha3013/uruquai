"""Build a QUBO matrix for the sensor-placement knapsack problem.

Formulation (maximisation, no slack bits)
------------------------------------------
Maximise  Σᵢ wᵢ xᵢ   subject to  Σᵢ cᵢ xᵢ ≤ B,  xᵢ ∈ {0,1}

Written as an unconstrained minimisation (QAOA minimises):

    min f(x) = −Σᵢ wᵢ xᵢ  +  λ · (Σᵢ cᵢ xᵢ − B)²

Expanding the penalty and collecting terms (using xᵢ² = xᵢ):

    Q[i,i] = −wᵢ  +  λ · cᵢ · (cᵢ − 2B)        (diagonal)
    Q[i,j] =          2λ · cᵢ · cⱼ               (upper triangle, i < j)

λ choice
--------
λ must exceed Σwᵢ so that any budget violation costs more than the maximum
possible objective gain.  The default ``effective_lambda`` in AppConfig sets
λ = 1 + Σwᵢ, which satisfies this for normalised weights ∈ [0,1].

Note: unlike the original quantum_exp.ipynb the constraint is enforced
as a *soft penalty* (no slack bits), so the budget boundary is approximate.
The brute_force() function below checks feasibility exactly.
"""
from __future__ import annotations

import numpy as np

from .config import AppConfig


def build_qubo(cfg: AppConfig) -> tuple[np.ndarray, dict]:
    """Return the QUBO matrix Q and a metadata dict.

    Parameters
    ----------
    cfg : AppConfig
        Populated configuration with sites, budget, and lambda.

    Returns
    -------
    Q : np.ndarray, shape (n, n)
        Upper-triangular QUBO matrix (Q[i,j] = 0 for i > j).
    meta : dict
        Summary statistics: n_qubits, lambda, budget, q_min, q_max.
    """
    n   = cfg.n_sites
    w   = cfg.weights
    c   = cfg.costs
    B   = float(cfg.budget_10k)
    lam = cfg.effective_lambda

    Q = np.zeros((n, n))

    # Objective term: −wᵢ on sensor diagonals
    for i in range(n):
        Q[i, i] -= w[i]

    # Penalty diagonal: λ·cᵢ·(cᵢ − 2B)
    for i in range(n):
        Q[i, i] += lam * c[i] * (c[i] - 2 * B)

    # Penalty off-diagonal: 2λ·cᵢ·cⱼ
    for i in range(n):
        for j in range(i + 1, n):
            Q[i, j] += 2 * lam * c[i] * c[j]

    meta = {
        "n_qubits": n,
        "lambda":   lam,
        "budget":   B,
        "q_min":    float(Q.min()),
        "q_max":    float(Q.max()),
    }
    return Q, meta


def brute_force(cfg: AppConfig, Q: np.ndarray) -> dict:
    """Enumerate all 2^n bitstrings and return the best feasible solution.

    Returns
    -------
    dict with keys: obj (float), x (np.ndarray), cost (float).
    """
    n = cfg.n_sites
    c = cfg.costs
    w = cfg.weights
    B = float(cfg.budget_10k)

    best: dict = {"obj": -np.inf, "x": None, "cost": None}

    for idx in range(2 ** n):
        x    = np.array([int(b) for b in format(idx, f"0{n}b")], dtype=float)
        cost = float(c @ x)
        if cost <= B:
            obj = float(w @ x)
            if obj > best["obj"]:
                best = {"obj": obj, "x": x.copy(), "cost": cost}

    return best
