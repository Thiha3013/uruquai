"""QAOA optimiser using PennyLane's AdamOptimizer.

Circuit structure (p layers)
-----------------------------
|+⟩^⊗n  →  [cost_layer(γₗ) · mixer_layer(βₗ)]_{l=1..p}  →  ⟨H_cost⟩

Optimisation
------------
Gradient-based Adam (``qml.AdamOptimizer``) minimises ⟨H_cost⟩ over
2p parameters (p gammas + p betas).  Starts from a random initialisation
in [0, π/2] with ``np.random.seed(42)`` for reproducibility.

Solution extraction
-------------------
After optimisation, ``qml.probs`` returns the full 2ⁿ distribution.
We scan the top-500 highest-probability bitstrings and return the
best *feasible* one (Σcᵢxᵢ ≤ B).
"""
from __future__ import annotations

import numpy as np
import pennylane as qml

from .config import AppConfig
from .ising import build_pennylane_hamiltonian
from .backends import get_device


def run_qaoa(cfg: AppConfig, h: np.ndarray, J: np.ndarray) -> dict:
    """Run QAOA and return results.

    Parameters
    ----------
    cfg : AppConfig
        Run configuration (p_layers, n_steps, stepsize, backend, …).
    h : np.ndarray, shape (n,)
        Ising local fields from :func:`~manzanillo_qc.ising.qubo_to_ising`.
    J : np.ndarray, shape (n, n)
        Ising coupling matrix (upper triangle).

    Returns
    -------
    dict with keys:
        opt_params    – optimised [γ₁,…,γₚ, β₁,…,βₚ]
        cost_history  – ⟨H_cost⟩ at each Adam step
        probs         – full 2ⁿ probability distribution
        best_x        – best feasible sensor-selection vector (0/1)
        best_obj      – risk coverage Σwᵢxᵢ for best_x
        best_cost     – CAPEX Σcᵢxᵢ for best_x
        best_prob     – circuit probability of best_x
        final_expval  – ⟨H_cost⟩ at last Adam step
    """
    n = len(h)
    H_cost, H_mix = build_pennylane_hamiltonian(h, J)
    dev = get_device(cfg.backend, n)
    p   = cfg.p_layers

    # ── Circuit definitions ────────────────────────────────────────────────────
    @qml.qnode(dev)
    def circuit_cost(params):
        gammas = params[:p]
        betas  = params[p:]
        for i in range(n):
            qml.Hadamard(wires=i)
        for l in range(p):
            qml.qaoa.cost_layer(gammas[l], H_cost)
            qml.qaoa.mixer_layer(betas[l],  H_mix)
        return qml.expval(H_cost)

    @qml.qnode(dev)
    def circuit_probs(params):
        gammas = params[:p]
        betas  = params[p:]
        for i in range(n):
            qml.Hadamard(wires=i)
        for l in range(p):
            qml.qaoa.cost_layer(gammas[l], H_cost)
            qml.qaoa.mixer_layer(betas[l],  H_mix)
        return qml.probs(wires=range(n))

    # ── Adam optimisation ──────────────────────────────────────────────────────
    np.random.seed(42)
    params = np.random.uniform(0, np.pi / 2, 2 * p)
    opt    = qml.AdamOptimizer(stepsize=cfg.stepsize)

    cost_history: list[float] = []
    for step in range(cfg.n_steps):
        params, cost_val = opt.step_and_cost(circuit_cost, params)
        cost_history.append(float(cost_val))
        if (step + 1) % 50 == 0:
            print(f"  step {step+1:4d}  ⟨H⟩ = {cost_val:.4f}")

    # ── Extract best feasible solution ─────────────────────────────────────────
    probs  = circuit_probs(params)
    c_arr  = cfg.costs
    w_arr  = cfg.weights
    B      = float(cfg.budget_10k)
    n_scan = min(500, len(probs))

    best: dict = {"obj": -np.inf, "x": None, "cost": None, "prob": 0.0}
    for idx in np.argsort(probs)[::-1][:n_scan]:
        x   = np.array([int(b) for b in format(idx, f"0{n}b")], dtype=float)
        tot = float(c_arr @ x)
        if tot <= B:
            obj = float(w_arr @ x)
            if obj > best["obj"]:
                best = {"obj": obj, "x": x.copy(), "cost": tot, "prob": float(probs[idx])}

    return {
        "opt_params":   params,
        "cost_history": cost_history,
        "probs":        probs,
        "best_x":       best["x"],
        "best_obj":     best["obj"],
        "best_cost":    best["cost"],
        "best_prob":    best["prob"],
        "final_expval": cost_history[-1] if cost_history else float("nan"),
    }
