"""manzanillo_qc — Quantum sensor placement for the Manzanillo seismic region.

Package layout
--------------
config.py    – Pydantic data models (SiteCandidate, AppConfig) + YAML loader
instance.py  – Live data pipeline: USGS catalog + FDSN stations → SiteCandidates
qubo.py      – QUBO matrix builder (maximisation form, no slack bits)
ising.py     – QUBO → Ising (h, J) conversion + PennyLane Hamiltonian factory
qaoa.py      – QAOA circuit + AdamOptimizer loop
backends.py  – PennyLane device factory
cli.py       – Command-line entry-point
"""
__version__ = "0.1.0"
__all__ = ["config", "instance", "qubo", "ising", "qaoa", "backends", "cli"]
